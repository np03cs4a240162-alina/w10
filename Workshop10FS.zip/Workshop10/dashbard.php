<?php
require 'session.php';
require 'db.php';

// Logout handler
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit;
}

$user_email = '';

if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT email FROM users WHERE id = :id");
    $stmt->execute([':id' => $_SESSION['user_id']]);
    $user = $stmt->fetch();

    if ($user) {
        $user_email = $user['email'];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>

<h1>Welcome to My Site</h1>

<?php if ($user_email): ?>
    <p>Logged in as:
        <?php echo htmlspecialchars($user_email); ?>
    </p>

    <form method="POST">
        <button type="submit" name="logout">Logout</button>
    </form>

<?php else: ?>
    <a href="login.php">
        <button>Login</button>
    </a>
<?php endif; ?>

</body>
</html>